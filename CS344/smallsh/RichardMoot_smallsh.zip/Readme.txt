To compile the program run the following in the console:
gcc -o smallsh main.c

You can also simply run "make"

If you want to clean the directory, run "make clean"