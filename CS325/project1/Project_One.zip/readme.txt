In order to run this program, you simply need it in the same directory as MSS_Problems.txt.

run "python algorithms.py"

You should see the results show in your console and also written into MSS_Results.txt in the same directory.
